package top.hiccup.guide.convert.impl;

import java.util.Map;

import top.hiccup.guide.GuideContext;
import top.hiccup.guide.convert.Convertor;
import top.hiccup.guide.exception.CheckRuleException;
import top.hiccup.guide.exception.ConvertException;
import top.hiccup.guide.exception.InvalidInputException;
import top.hiccup.guide.rule.Rule;

/**
 * 将罗马字符串转换为整形
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class RomanConvertor implements Convertor {

    @Override
    public Integer stringToInteger(String s) throws CheckRuleException {
        if (s == null || s.length() == 0) {
            throw new ConvertException("被转换参数不能为空");
        }
        Rule rule = GuideContext.getRule();
        Rule.Result repeatedRuleResult = rule.checkRepeatedRule(s);
        if (!repeatedRuleResult.isPassed()) {
            throw new CheckRuleException(repeatedRuleResult.getMessage());
        }
        char[] chars = s.toCharArray();
        int count = 0;
        Map<Character, Integer> map = GuideContext.getMapper().getSymbolToDigitMapping();
        int i = 0;
        for (i = 0; i < chars.length - 1; i++) {
            char cur = chars[i];
            if (!map.containsKey(cur)) {
                throw new InvalidInputException("非法输入：" + String.valueOf(cur));
            }
            char next = chars[i + 1];
            int curVal = map.get(cur).intValue();
            int nextVal = map.get(next).intValue();
            if (curVal < nextVal) {
                Rule.Result subtractionRuleResult = rule.checkSubtractionRule(next, cur);
                if (!subtractionRuleResult.isPassed()) {
                    throw new CheckRuleException(subtractionRuleResult.getMessage());
                }
                count += (nextVal - curVal);
                i++;
            } else {
                count += curVal;
            }
        }
        if (i != chars.length) {
            count += map.get(chars[chars.length - 1]).intValue();
        }
        return count;
    }
}
