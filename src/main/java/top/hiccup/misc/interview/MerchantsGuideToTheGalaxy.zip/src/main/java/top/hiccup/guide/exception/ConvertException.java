package top.hiccup.guide.exception;

/**
 * 转换异常
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class ConvertException extends RuntimeException {

    public ConvertException(String message) {
        super(message);
    }

    public ConvertException(String message, Throwable cause) {
        super(message, cause);
    }
}
