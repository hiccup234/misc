package top.hiccup.guide.map.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import top.hiccup.guide.map.SymbolAndDigitMapping;

/**
 * 罗马字符与数字的映射实现类
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class RomanAndDigitMapping implements SymbolAndDigitMapping {

    private static final Map<Character, Integer> map = new HashMap<>();

    static {
        map.put('I', 1);
        map.put('V', 5);
        map.put('X', 10);
        map.put('L', 50);
        map.put('C', 100);
        map.put('D', 500);
        map.put('M', 1000);
    }

    @Override
    public final Map<Character, Integer> getSymbolToDigitMapping() {
        return Collections.unmodifiableMap(map);
    }
}
