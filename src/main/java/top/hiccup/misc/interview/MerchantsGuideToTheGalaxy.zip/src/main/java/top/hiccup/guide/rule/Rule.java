package top.hiccup.guide.rule;

/**
 * 校验规则
 *
 * @author wenhy
 * @date 2019/7/9
 */
public interface Rule {

    /**
     * 校验符号重复规则
     *
     * @param s
     * @return
     */
    Result checkRepeatedRule(String s);

    /**
     * 校验符号间减法运算规则， c1 - c2
     *
     * @param c1
     * @param c2
     * @return
     */
    Result checkSubtractionRule(Character c1, Character c2);

    /**
     * 规则检查结果类
     */
    class Result {
        private boolean passed;
        private String message;

        public Result(boolean passed, String message) {
            this.passed = passed;
            this.message = message;
        }

        public boolean isPassed() {
            return passed;
        }

        public void setPassed(boolean passed) {
            this.passed = passed;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
