package top.hiccup.guide.exception;

/**
 * 规则校验异常
 *
 * @author wenhy
 * @date 2019/7/9
 */
public class CheckRuleException extends Exception{

    public CheckRuleException(String message) {
        super(message);
    }

    public CheckRuleException(String message, Throwable cause) {
        super(message, cause);
    }
}
