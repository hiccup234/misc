package top.hiccup.guide;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import top.hiccup.guide.exception.CheckRuleException;
import top.hiccup.guide.exception.InvalidInputException;

/**
 * 面试题“Merchant's Guide to the Galaxy”的主入口类
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class Main {

    private static String inputPath = null;

    public static void main(String[] args) throws UnsupportedEncodingException {
        if (args == null || args.length < 1) {
            throw new InvalidInputException("启动参数错误，请加上命令行参数：输入文件的路径");
        }
        inputPath = args[0];
        inputPath = URLDecoder.decode(inputPath, "UTF-8");
        try {
            // 1、读入文件内容并对语句分类
            InputHandler.readFile(inputPath);
            // 2、按问题分类进行处理
            InputHandler.process();
            // 3、打印问题答案
            InputHandler.printAnswer();
        } catch (CheckRuleException e) {
            System.out.println(e.getMessage());
        } catch (InvalidInputException e2) {
            System.out.println(e2.getMessage());
        } catch (Exception e) {
            System.err.println("程序出错：" + e.getMessage());
        }
    }
}
