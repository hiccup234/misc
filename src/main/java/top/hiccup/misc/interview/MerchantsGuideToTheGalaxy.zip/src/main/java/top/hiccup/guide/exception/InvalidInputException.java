package top.hiccup.guide.exception;

/**
 * 非法输入异常
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class InvalidInputException extends InputException {

    public InvalidInputException(String message) {
        super(message);
    }

    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}
