package top.hiccup.guide;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

import org.junit.Assert;
import org.junit.Test;

/**
 * 程序主入口单元测试类
 *
 * @author wenhy
 * @date 2019/7/9
 */
public class MainTest {

    @Test
    public void main() throws UnsupportedEncodingException {
        PrintStream out = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        System.setOut(new PrintStream(baos));
        String classpath = MainTest.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        // 测试合法输入
        Main.main(new String[]{classpath + "input.txt"});
        String lineSeparator = System.lineSeparator();
        Assert.assertEquals("pish tegj glob glob is 42" + lineSeparator +
                        "glob prok Silver is 68 Credits" + lineSeparator +
                        "glob prok Gold is 57800 Credits" + lineSeparator +
                        "glob prok Iron is 782 Credits" + lineSeparator +
                        "I have no idea what you are talking about" + lineSeparator
                , baos.toString());

        // 测试非法输入
        baos.reset();
        Main.main(new String[]{classpath + "invalidInput.txt"});
        Assert.assertEquals("非法输入：globs prok Gold is 57800 Credits" + lineSeparator, baos.toString());
        out.println(baos.toString());
        System.setOut(out);
    }
}
