package top.hiccup.guide.rule.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import top.hiccup.guide.GuideContext;
import top.hiccup.guide.rule.Rule;

/**
 * 罗马数字校验规则
 *
 * @author wenhy
 * @date 2019/7/9
 */
public class RomanRule implements Rule {

    /**
     * 可重复符号
     */
    private static final List<Character> repeatableSymbolList = Arrays.asList(new Character[]{'I', 'X', 'C', 'M'});
    /**
     * 不可重复符号
     */
    private static final List<Character> noRepeatableSymbolList = Arrays.asList(new Character[]{'D', 'L', 'V'});

    /**
     * 可被减去的符号映射
     */
    private static final Map<Character, List<Character>> canSubtractionSymbolMapping = new HashMap<>(4);

    static {
        // “I”只能从“V”和“X”中减去，其他依此类推
        canSubtractionSymbolMapping.put('I', Arrays.asList(new Character[]{'V', 'X'}));
        canSubtractionSymbolMapping.put('X', Arrays.asList(new Character[]{'L', 'C'}));
        canSubtractionSymbolMapping.put('C', Arrays.asList(new Character[]{'D', 'M'}));

    }

    /**
     * 不可作为减数的符号
     */
    private static final List<Character> cannotSubtractionSymbolList = Arrays.asList(new Character[]{'V', 'L', 'D'});

    @Override
    public Rule.Result checkRepeatedRule(String s) {
        char[] arr = s.toCharArray();
        char preChar = arr[0];
        int repeatedCount = 1;
        for (int i = 1; i < arr.length; i++) {
            // 与前一个符号相等则证明是重复得
            if (preChar == arr[i]) {
                if (repeatableSymbolList.contains(preChar)) {
                    repeatedCount++;
                    if (repeatedCount > 3) {
                        return new Rule.Result(false, "校验规则异常：符号【" + preChar + "】重复次数超过3次");
                    }
                    continue;
                } else if (noRepeatableSymbolList.contains(preChar)) {
                    return new Rule.Result(false, "校验规则异常：符号【" + preChar + "】不能重复");
                }
            } else {
                preChar = arr[i];
            }
        }
        return new Rule.Result(true, null);
    }

    @Override
    public Rule.Result checkSubtractionRule(Character c1, Character c2) {
        if (cannotSubtractionSymbolList.contains(c2)) {
            return new Rule.Result(false, "校验规则异常：符号【" + c2 + "】不能作为减数");
        }
        if (canSubtractionSymbolMapping.containsKey(c2)) {
            List<Character> canBeenSubtractionList = canSubtractionSymbolMapping.get(c2);
            if (!canBeenSubtractionList.contains(c1)) {
                return new Rule.Result(false, "校验规则异常：符号【" + c1 + "】不能被符号【" + c2 + "】减去");
            }
        }
        Map<Character, Integer> map = GuideContext.getMapper().getSymbolToDigitMapping();
        if (map.get(c1) <= map.get(c2)) {
            return new Rule.Result(false, "校验规则异常：小值符号【" + c1 + "】不能减去大值符号【" + c2 + "】");
        }
        return new Rule.Result(true, null);
    }
}
