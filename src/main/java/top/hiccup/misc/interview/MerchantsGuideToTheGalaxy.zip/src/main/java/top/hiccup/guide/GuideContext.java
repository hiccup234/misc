package top.hiccup.guide;

import top.hiccup.guide.convert.Convertor;
import top.hiccup.guide.convert.impl.RomanConvertor;
import top.hiccup.guide.map.SymbolAndDigitMapping;
import top.hiccup.guide.map.impl.RomanAndDigitMapping;
import top.hiccup.guide.rule.impl.RomanRule;
import top.hiccup.guide.rule.Rule;

/**
 * 指南程序上下文
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class GuideContext {

    /**
     * 指定采用的映射关系类
     *
     * @return
     */
    public static SymbolAndDigitMapping getMapper() {
        return new RomanAndDigitMapping();
    }

    /**
     * 指定采用的转换器
     *
     * @return
     */
    public static Convertor getConvertor() {
        return new RomanConvertor();
    }

    /**
     * 指定校验规则
     *
     * @return
     */
    public static Rule getRule() {
        return new RomanRule();
    }
}
