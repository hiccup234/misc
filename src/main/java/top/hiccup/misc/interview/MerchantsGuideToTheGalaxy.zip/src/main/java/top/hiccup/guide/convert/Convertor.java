package top.hiccup.guide.convert;

import top.hiccup.guide.exception.CheckRuleException;

/**
 * 定义转换器接口
 *
 * @author wenhy
 * @date 2019/7/8
 */
public interface Convertor {

    /**
     * 将String转换为Integer
     *
     * @param s
     * @return
     */
    Integer stringToInteger(String s) throws CheckRuleException;
}
