package top.hiccup.guide.map;

import java.util.Map;

/**
 * 符号与数字的映射接口
 *
 * @author wenhy
 * @date 2019/7/8
 */
public interface SymbolAndDigitMapping {

    /**
     * 获取符号映射到数字的关系
     *
     * @return
     */
    Map<Character, Integer> getSymbolToDigitMapping();
}
