package top.hiccup.guide.rule;

import org.junit.Assert;
import org.junit.Test;

import top.hiccup.guide.rule.impl.RomanRule;

/**
 * 罗马数字校验规则单元测试类
 *
 * @author wenhy
 * @date 2019/7/9
 */
public class RomanRuleTest {

    @Test
    public void checkRepeatedRule() {
        RomanRule rule = new RomanRule();
        Assert.assertTrue(!rule.checkRepeatedRule("XXXXI").isPassed());
        Assert.assertTrue(rule.checkRepeatedRule("XXXIX").isPassed());
        Assert.assertTrue(!rule.checkRepeatedRule("VVVXV").isPassed());
    }

    @Test
    public void checkSubtractionRule() {
        RomanRule rule = new RomanRule();
        Assert.assertTrue(rule.checkSubtractionRule('V', 'I').isPassed());
        Assert.assertTrue(!rule.checkSubtractionRule('D', 'I').isPassed());

        Assert.assertTrue(rule.checkSubtractionRule('C', 'X').isPassed());
        Assert.assertTrue(!rule.checkSubtractionRule('V', 'X').isPassed());

        Assert.assertTrue(rule.checkSubtractionRule('D', 'C').isPassed());
        Assert.assertTrue(!rule.checkSubtractionRule('V', 'C').isPassed());

        Assert.assertTrue(!rule.checkSubtractionRule('D', 'V').isPassed());
    }
}
