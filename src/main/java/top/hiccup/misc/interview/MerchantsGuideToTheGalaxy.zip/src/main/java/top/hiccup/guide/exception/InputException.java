package top.hiccup.guide.exception;

/**
 * 输入处理异常
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class InputException extends RuntimeException {

    public InputException(String message) {
        super(message);
    }

    public InputException(String message, Throwable cause) {
        super(message, cause);
    }
}
