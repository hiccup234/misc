package top.hiccup.guide.convert;

import org.junit.Assert;
import org.junit.Test;

import top.hiccup.guide.convert.impl.RomanConvertor;
import top.hiccup.guide.exception.CheckRuleException;

/**
 * 将罗马字符串转换为整形测试类
 *
 * @author wenhy
 * @date 2019/7/9
 */
public class RomanConvertorTest {

    @Test
    public void stringToInteger() {
        RomanConvertor romanConvertor = new RomanConvertor();
        try {
            Assert.assertTrue(1000 == romanConvertor.stringToInteger("M"));
            Assert.assertTrue(900 == romanConvertor.stringToInteger("CM"));
            Assert.assertTrue(3 == romanConvertor.stringToInteger("III"));
            Assert.assertTrue(1903 == romanConvertor.stringToInteger("MCMIII"));
        } catch (CheckRuleException e) {
            throw new RuntimeException(e);
        }

        try {
            Assert.assertTrue(80 == romanConvertor.stringToInteger("XXXXIIII"));
            // 如果程序运行到这里则证明stringToInteger没有抛出异常，单元测试失败
            Assert.assertTrue(false);
        } catch (CheckRuleException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }
}
