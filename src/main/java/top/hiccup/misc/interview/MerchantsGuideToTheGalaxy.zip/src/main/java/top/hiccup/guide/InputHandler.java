package top.hiccup.guide;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import top.hiccup.guide.exception.CheckRuleException;
import top.hiccup.guide.exception.InputException;
import top.hiccup.guide.exception.InvalidInputException;

import static java.math.BigDecimal.ROUND_CEILING;

/**
 * 处理文件的输入
 *
 * @author wenhy
 * @date 2019/7/8
 */
public class InputHandler {

    /**
     * 别名语句的单词个数
     */
    private static final int ALIAS_WORDS_COUNT = 3;

    /**
     * 别名的语句标识符
     */
    private static final String ALIAS_SYMBOL = "is";

    /**
     * 价格语句的结尾标识符
     */
    private static final String CREDITS_SYMBOL = "Credits";

    /**
     * 提问语句的结尾标识符（需要做出回答）
     */
    private static final String QUESTION_END_SYMBOL = "?";

    /**
     * 分割语句的正则表达式，分割单词而不是分割空格，可以防止单词间有多个空格的问题
     */
    private static final String SPLIT_REGEX = "[^a-zA-Z0-9]+";

    /**
     * 不规范提问的回答语句
     */
    private static final String INVALID_QUESTION_ANSWOR = "I have no idea what you are talking about";

    /**
     * 存储别名定义语句
     */
    private static ArrayList<String> aliasList = new ArrayList<>(4);

    /**
     * 存储价格定义语句
     */
    private static ArrayList<String> creditList = new ArrayList<>(3);

    /**
     * 存储每个问句及其对应回答
     */
    private static Map<String, String> questionAndAnswerMap = new LinkedHashMap<>(8);

    /**
     * 别名映射关系
     */
    private static Map<String, String> aliasMap = new HashMap<>(8);

    /**
     * 每项物品的单价映射关系
     */
    private static Map<String, BigDecimal> perCreditMap = new HashMap<>(8);

    /**
     * 读取输入文件的内容，并按行处理
     *
     * @param inputPath
     */
    public static void readFile(String inputPath) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(new File(inputPath)));
            String line = null;
            while ((line = br.readLine()) != null) {
                preProcessLine(line);
            }
        } catch (Exception e) {
            throw new InputException("处理输入异常：", e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 预处理每行数据，这里仅仅对问题分类，将I/O处理与业务逻辑处理分开以节省对I/O资源的占用
     *
     * @param line
     */
    private static void preProcessLine(String line) {
        line = line.trim();
        // 如果是以QUESTION_END_SYMBOL结尾，则表明这是一个问题，需要做出回答
        if (line.endsWith(QUESTION_END_SYMBOL)) {
            questionAndAnswerMap.put(line, null);
            return;
        }
        String[] arr = line.split(SPLIT_REGEX);
        if (arr.length == ALIAS_WORDS_COUNT && ALIAS_SYMBOL.equalsIgnoreCase(arr[1])) {
            aliasList.add(line);
        } else if (line.endsWith(CREDITS_SYMBOL)) {
            creditList.add(line);
        }
    }

    /**
     * 按问题分类进行处理
     */
    public static void process() throws CheckRuleException {
        // 1、处理别名
        processAlias();
        // 2、处理物品单价
        processCredits();
        // 3、处理输入文件中的问题
        processQuestion();
    }

    /**
     * 处理别名定义
     */
    private static void processAlias() {
        Map<Character, Integer> mapping = GuideContext.getMapper().getSymbolToDigitMapping();
        Set<Character> keySet = mapping.keySet();
        aliasList.forEach((alias) -> {
            String[] arr = alias.split(SPLIT_REGEX);
            String symbol = arr[2];
            if (keySet.contains(new Character(symbol.charAt(0)))) {
                aliasMap.put(arr[0], arr[2]);
            } else {
                throw new InvalidInputException("非法输入：" + symbol);
            }
        });
    }

    /**
     * 处理价格定义，转换出每件物品的单价
     */
    private static void processCredits() throws CheckRuleException {
        if (creditList != null && creditList.size() > 0) {
            for (String s : creditList) {
                String[] arr = s.split(SPLIT_REGEX);
                String goodName = null;
                int priceIndex = 0;
                int credit = 0;
                for (int i = 0; i < arr.length; i++) {
                    if (arr[i].toLowerCase().equals("credits")) {
                        credit = Integer.parseInt(arr[i - 1]);
                    }
                    if (arr[i].toLowerCase().equals("is")) {
                        priceIndex = i - 1;
                        goodName = arr[i - 1];
                    }
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < priceIndex; i++) {
                    if (aliasMap.containsKey(arr[i])) {
                        sb.append(aliasMap.get(arr[i]));
                    } else {
                        throw new InvalidInputException("非法输入：" + s);
                    }
                }
                Integer value = GuideContext.getConvertor().stringToInteger(sb.toString());
                perCreditMap.put(goodName, BigDecimal.valueOf(credit).divide(BigDecimal.valueOf(value), 10, ROUND_CEILING));
            }
        }
    }

    /**
     * 处理提问语句
     */
    private static void processQuestion() {
        for (Map.Entry<String, String> entry : questionAndAnswerMap.entrySet()) {
            String question = entry.getKey();
            if (question.toLowerCase().startsWith("how much is")) {
                processValueQuestion(entry);
            } else if (question.toLowerCase().startsWith("how many credits is")) {
                processCreditQuestion(entry);
            } else {
                entry.setValue(INVALID_QUESTION_ANSWOR);
            }
        }
    }

    /**
     * 处理求值语句
     *
     * @param entry
     */
    private static void processValueQuestion(Map.Entry<String, String> entry) {
        String question = entry.getKey();
        question = question.substring(12, question.length() - 2);
        String[] arr = question.split(SPLIT_REGEX);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            sb.append(aliasMap.get(arr[i]));
        }
        try {
            Integer value = GuideContext.getConvertor().stringToInteger(sb.toString());
            entry.setValue(question + " is " + String.valueOf(value));
        } catch (Exception e) {
            entry.setValue(INVALID_QUESTION_ANSWOR);
        }
    }

    /**
     * 处理求价格语句
     *
     * @param entry
     */
    private static void processCreditQuestion(Map.Entry<String, String> entry) {
        String question = entry.getKey();
        question = question.substring(20, question.length() - 2);
        String[] arr = question.split(SPLIT_REGEX);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length - 1; i++) {
            sb.append(aliasMap.get(arr[i]));
        }
        try {
            Integer value = GuideContext.getConvertor().stringToInteger(sb.toString());
            BigDecimal perCredit = perCreditMap.get(arr[arr.length - 1]);
            entry.setValue(question + " is " + perCredit.multiply(BigDecimal.valueOf(value)).stripTrailingZeros().toPlainString() + " Credits");
        } catch (Exception e) {
            entry.setValue(INVALID_QUESTION_ANSWOR);
        }
    }

    /**
     * 打印问题答案
     */
    public static void printAnswer() {
        for (Map.Entry<String, String> entry : questionAndAnswerMap.entrySet()) {
            System.out.println(entry.getValue());
        }
    }
}
